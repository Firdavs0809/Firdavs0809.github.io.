# -*- coding: utf-8 -*-
#####0,1,2,3,4,5,6,7
# fer=[2,3,6,7,3,3,3,2]
# def dist(ferg):
#     n=0
#     while fer:
#         for x in fer:
#             print(x)
#             while x in fer:
#                 fer.remove(x)
#             n=n+1
#     return n 
# print(f"There are {dist(fer)} distinct elements")




# def say_time_repitition(a):
#     order={}
#     while num:
#         for x in num:
#             n=0
#             while x in num:
#                 num.remove(x)
#                 n=n+1
#             order[x]=n
#     return order
# num=[12,11,13,14,12,11,10,10,10,10]
# print(say_time_repitition(num))           
 


       
# def reverse_list(k):
#     k.reverse()
#     return k
# numbers=[5,6,3,4,15,0,1,9]
# print(reverse_list(numbers))



# rot_list=[0,1,2,3,4,5,6,7,8,9]
# times=int(input("Enter the times of rotation:"))
# def rotate(l_i_s_t,n):
#     while n>0:
#         a=l_i_s_t.pop(-1)
#         l_i_s_t.insert(0,a )
#         n=n-1
#     return l_i_s_t   
# print(rotate(rot_list,times))   


# word=input("Input any word:")
# letters=input("Enter any letter:") 
# def letter(word,letters):
#     n=0
#     if letters in word:
#         for x in word:
#             if x==letters:
#                 return f"{n+1}-letter of the word  is {letters}"
#             else:
#                 n=n+1
#     if letters not in word:
#         return "This letter does not exist "
# print(letter(word, letters))         
                
        
    



































